package com.example.demo1;
import  java.sql.*;
public class SQLConnector {

    public Connection createConnection() throws SQLException {
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/movies","root","");
        return con;
    }
}
