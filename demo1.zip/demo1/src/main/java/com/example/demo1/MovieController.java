package com.example.demo1;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import org.w3c.dom.Text;

import java.sql.Connection;
import java.sql.SQLException;

public class MovieController {
    SQLConnector sqlcon = new SQLConnector();
    Connection con = sqlcon.createConnection();
    @FXML
    private Button fetchbtn;
    @FXML
    private Button getbtn;

    @FXML
    private TextField nameinp;
    @FXML
    private TextField categoryinp;
    @FXML
    private TextField priceinp;
    @FXML
    private TextField durationinp;
    @FXML
    private PieChart piechart;
    @FXML
    private Button addchart;


    public MovieController() throws SQLException {
    }

    @FXML
    protected void onGetButtonClick() throws SQLException {
        Movie.getMovies(con);
    }

    @FXML
    protected void onAddButtonClick() throws SQLException {
        Movie.addMovies(con, nameinp.getText(), categoryinp.getText(), priceinp.getText(), durationinp.getText());
    }

    @FXML
    protected void addpiechart() throws SQLException {
        Movie.getDurationChart(con, piechart);
    }

}